HTML/CSS -Prototyp-Abgabe
Gruppe 4
Team: Good Food Market
Prof. Dr. German Nemirovski


Brucklacher, Luca
Gür, Berna
Sander, Rudolf


*Die Webseite wurde auf Monitoren mit einer Auflösung von mindestens 1920 × 1080 Pixeln programmiert.